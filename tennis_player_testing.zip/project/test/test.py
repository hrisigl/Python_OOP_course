from unittest import TestCase, main

from project.tennis_player import TennisPlayer


class TennisPlayerTests(TestCase):
    def setUp(self) -> None:
        self.player = TennisPlayer("Hrisi", 23, 100)

    def test_init(self):
        self.assertEqual("Hrisi", self.player.name)
        self.assertEqual(23, self.player.age)
        self.assertEqual(100, self.player.points)
        self.assertEqual([], self.player.wins)

    def test_name_raises(self):
        with self.assertRaises(ValueError) as ve:
            self.player.name = "Hr"

        self.assertEqual("Name should be more than 2 symbols!", str(ve.exception))

    def test_age_raises(self):
        with self.assertRaises(ValueError) as ve:
            self.player.age = 10

        self.assertEqual("Players must be at least 18 years of age!", str(ve.exception))

    def test_add_new_win_name_does_not_exist(self):
        self.assertEqual([], self.player.wins)
        self.player.add_new_win("berk")
        self.assertEqual(["berk"], self.player.wins)

        self.player.add_new_win("mont")
        self.assertEqual(["berk", "mont"], self.player.wins)

    def test_add_new_win_name_exist(self):
        self.player.wins = ["berk"]
        res = self.player.add_new_win("berk")
        self.assertEqual("berk has been already added to the list of wins!", res)

    def test_lt_true(self):
        other_player = TennisPlayer("Neli", 24, 150)
        res = self.player.__lt__(other_player)
        expected = "Neli is a top seeded player and he/she is better than Hrisi"
        self.assertEqual(expected, res)

    def test_lt_false(self):
        other_player = TennisPlayer("Neli", 24, 99)
        res = self.player.__lt__(other_player)
        expected = "Hrisi is a better player than Neli"
        self.assertEqual(expected, res)

    def test_str(self):
        self.player.wins = ["berk", "mont"]
        expected = f"Tennis Player: Hrisi\n" \
                   f"Age: 23\n" \
                   f"Points: 100.0\n" \
                   f"Tournaments won: berk, mont"
        res = str(self.player)
        self.assertEqual(expected, res)


if __name__ == "__main__":
    main()
